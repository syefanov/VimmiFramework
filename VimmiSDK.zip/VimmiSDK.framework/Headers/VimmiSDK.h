//
//  VimmiSDK.h
//  VimmiSDK
//
//  Created by Serhii Yefanov on 6/7/18.
//  Copyright © 2018 Serhii Yefanov. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for VimmiSDK.
//FOUNDATION_EXPORT double VimmiSDKVersionNumber;

//! Project version string for VimmiSDK.
//FOUNDATION_EXPORT const unsigned char VimmiSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VimmiSDK/PublicHeader.h>

